package interfa;


public interface LinkedListNode {
    /***
     * linked list dependent
      */
    String toString();
}
